import javax.swing.*;
import java.util.Scanner;

public class tema3e1 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);

        String[] nombres = new String[4];
        nombres[0]="Jose ";
        nombres[1]="Maria ";
        nombres[2]="Alejandra ";
        nombres[3]="Karol ";

        for(String n : nombres){
            System.out.print(n);
        }
    }
}