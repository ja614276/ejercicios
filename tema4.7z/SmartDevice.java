public class SmartDevice {
    String color;
    String fabricante;
    String modelo;
    Double peso;
    Double largo;
    Integer bateria=0;

    public SmartDevice(){}
    public SmartDevice(String color, String fabricante, String modelo, Double peso, Double largo){
        this.color = color;
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.peso = peso;
        this.largo = largo;
    }

    public void consumo(Integer cantidad){
        if(cantidad>0 && cantidad<=100){
            this.bateria+=cantidad;
        }
    }

    @Override
    public String toString() {
        return "SmartDevice{" +
                "color='" + color + '\'' +
                ", fabricante='" + fabricante + '\'' +
                ", modelo='" + modelo + '\'' +
                ", peso=" + peso +
                ", largo=" + largo +
                ", bateria=" + bateria +
                '}';
    }
}

