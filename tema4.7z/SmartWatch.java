public class SmartWatch extends SmartDevice{
    public SmartWatch(String color, String fabricante, String modelo, Double peso, Double largo) {
        super(color, fabricante, modelo, peso, largo);
    }

    @Override
    public String toString() {
        return "SmartWatch{" +
                "color='" + color + '\'' +
                ", fabricante='" + fabricante + '\'' +
                ", modelo='" + modelo + '\'' +
                ", peso=" + peso +
                ", largo=" + largo +
                ", bateria=" + bateria +
                '}';
    }
}
