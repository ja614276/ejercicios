public class SDMain {
    public static void main(String[] args) {
        String SmartDevice;
        SmartDevice sdobj = new SmartDevice();

        SmartPhone SmartPhone = new SmartPhone("Negro", "Huawei", "ad-1111", 21.1, 16.1 );
        SmartPhone.bateria= 51;
        System.out.println(SmartPhone);

        SmartWatch SmartWatch = new SmartWatch("Blanco", "Apple", "Apple watch 5 ", 11.1, 12.1 );
        SmartWatch.bateria= 31;
        System.out.println(SmartWatch);
    }
}
