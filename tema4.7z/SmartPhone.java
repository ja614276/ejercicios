public class SmartPhone extends SmartDevice{
    public SmartPhone(String color, String fabricante, String modelo, Double peso, Double largo){
        super(color,fabricante,modelo,peso,largo);
    }

    @Override
    public String toString() {
        return "SmartPhone{" +
                "color='" + color + '\'' +
                ", fabricante='" + fabricante + '\'' +
                ", modelo='" + modelo + '\'' +
                ", peso=" + peso +
                ", largo=" + largo +
                ", bateria=" + bateria +
                '}';
    }
}